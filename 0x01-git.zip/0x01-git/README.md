Gibhub access token(Git-ALX)valid for 60days: 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


=============Sand box==============
Credentials
Host
eb27d02f839e.9657af53.alx-cod.online
Username
eb27d02f839e
Password
1e9e807177ebe14129cc
===================================
root@896cf839cf9a:/# git clone https://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@github.com/Mabontle22/alx-pre_course.git
===================================
Siya Percy - bot
---
Siya Bot Ndaba
16/12/90 Male
-Phone number
-22 Mdolomba Street Langa - Cape Town 7455
- Single
-073 549 1751
-90%Male*




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

ssh eb27d02f839e@eb27d02f839e.9657af53.alx-cod.online

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

git clone  https://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@github.com/Mabontle22/alx-pre_course.git

kqotso.kobo@nyda.gov